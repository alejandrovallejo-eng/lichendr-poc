# BioCLIP Cloud Run pilot

## Optional comparison, 17 September 2026

This package now also bundles the frozen `inat-five-class-20260917` candidate.
Only `experimental: true` requests invoke it. The original three-class head,
its SHA and its default preprocessing remain unchanged. The extra result is
separate and cannot accept masks, assign species or compute coverage.

The five classes are lichen, moss, bark, algae and non-lichenized fungus. A
training-only rejection policy may return undetermined. Scores are not
probabilities. The candidate did NOT pass lichen-recall promotion gates and
must not become the default. All three candidate files are SHA-256 pinned;
the API's bundle hash covers head, reference embeddings and rejection policy.

The Cloud Run service originally named preview now also serves Production.
Do not run the initial bootstrap script below to update it. Publish a tested
revision without changing IAM, secrets, scaling or runtime identity; verify
its private tagged URL before any traffic switch. The old revision remains
available for rollback. Local study details: experiments/inat-complete-20260917.

## Historical initial deployment notes (September 10)

Preview only. No Vercel, Render, Supabase, RLS or production settings are changed
by this package. The initial service requires Google IAM authentication AND the
worker bearer token; public invocation is not enabled by deploy-preview.sh.

Worker source copied from the locally validated PR18 QA fixture (base archive
932fe92; runtime changes through 9480304). Worker algorithms are unchanged here.
The integrated GitHub commit is 0f6a7dadfaad22c77f6e90a4fb5f26ae84365ca1.
This package is not a fresh Git clone of that commit and makes no such claim.

The new wrapper requires a strong token and pinned trained head, authenticates
before parsing request bodies, and exposes only a minimal /ready probe.
CPU-only PyTorch avoids downloading unnecessary CUDA libraries. Encoder weights
are downloaded at image build time from the upstream pinned revision and checked
by byte size and SHA256. They are not downloaded during inference. The trained
head is the exact classifier.npz validated locally, checked at build and startup.
No test photographs, credentials or datasets are included in the build context.

Cloud configuration: us-east1, 2 vCPU, 8 GiB, concurrency 1, minimum 0, maximum 1
at both service/revision levels, request-based CPU allocation, startup boost,
startup probe up to 240 seconds. Maximum instances and budgets are NOT hard
spending caps. Build, registry, secret and network costs can exist even when the
service scales to zero. The $10 budget is an alert, not a guarantee of total cost.

Run the script only in the authorized project's Cloud Shell. It creates the
runtime service account, its own secret, required APIs and build permission.
The runtime identity has no project-wide role; it can read only its own secret.
The script refuses to redeploy an existing service and does not rotate secrets.

Remaining validation: Linux image build; healthy loaded model/head; unauthorized
request rejection; real classifier call; cold start; then a separate authenticated
Preview integration. No production activation is authorized by this file.
