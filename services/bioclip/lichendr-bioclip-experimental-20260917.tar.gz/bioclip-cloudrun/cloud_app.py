"""Cloud-only fail-closed wrapper; the validated inference code is unchanged."""
import os
import secrets

from starlette.responses import JSONResponse
import app as worker

TOKEN = os.environ.get("BIOCLIP_WORKER_TOKEN", "")
if len(TOKEN) < 32:
    raise RuntimeError("A strong BIOCLIP_WORKER_TOKEN is required")
if not worker.ENABLED or not worker.HEAD_PATH or not worker.HEAD_SHA256:
    raise RuntimeError("Enabled worker and pinned trained head are required")


async def application(scope, receive, send):
    if scope["type"] != "http":
        return await worker.app(scope, receive, send)
    if scope["path"] == "/ready" and scope["method"] == "GET":
        ready = worker._state["encoder"] is not None and worker._state["head"] is not None
        return await JSONResponse({"ready": ready}, status_code=200 if ready else 503)(scope, receive, send)
    authorization = dict(scope.get("headers", [])).get(b"authorization", b"")
    if not secrets.compare_digest(authorization, ("Bearer " + TOKEN).encode()):
        return await JSONResponse({"detail": "unauthorized"}, status_code=401)(scope, receive, send)
    return await worker.app(scope, receive, send)
