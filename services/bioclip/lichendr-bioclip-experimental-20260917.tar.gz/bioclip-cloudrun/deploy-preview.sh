#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
project=lichendr
region=us-east1
service=lichendr-bioclip-preview
runtime=lichendr-bioclip-preview@lichendr.iam.gserviceaccount.com
secret=lichendr-bioclip-preview-token
test "$(gcloud config get-value project 2>/dev/null)" = "$project"
# Do not overwrite an existing service or rotate an existing secret on a rerun.
if gcloud run services describe "$service" --project="$project" --region="$region" >/dev/null 2>&1; then
  echo 'Service already exists. Inspect it before making another revision.' >&2
  exit 1
fi
gcloud services enable cloudbuild.googleapis.com artifactregistry.googleapis.com secretmanager.googleapis.com iam.googleapis.com --project="$project"
if ! gcloud iam service-accounts describe "$runtime" --project="$project" >/dev/null 2>&1; then
  gcloud iam service-accounts create lichendr-bioclip-preview --display-name='LichenDR BioCLIP preview only' --project="$project"
fi
if ! gcloud secrets describe "$secret" --project="$project" >/dev/null 2>&1; then
  python3 -c 'import secrets; print(secrets.token_urlsafe(48), end="")' | gcloud secrets create "$secret" --data-file=- --replication-policy=automatic --project="$project"
fi
gcloud secrets add-iam-policy-binding "$secret" --member="serviceAccount:$runtime" --role=roles/secretmanager.secretAccessor --project="$project" --quiet >/dev/null
gcloud projects add-iam-policy-binding "$project" --member=serviceAccount:838586175073-compute@developer.gserviceaccount.com --role=roles/run.builder --condition=None --quiet >/dev/null
gcloud run deploy "$service" --project="$project" --region="$region" \
  --source=. --service-account="$runtime" --no-allow-unauthenticated \
  --cpu=2 --memory=8Gi --concurrency=1 --min=0 --max=1 --max-instances=1 \
  --timeout=180 --cpu-throttling --cpu-boost \
  --startup-probe='httpGet.path=/ready,httpGet.port=8080,periodSeconds=10,timeoutSeconds=5,failureThreshold=24' \
  --set-secrets="BIOCLIP_WORKER_TOKEN=$secret:1" \
  --labels=application=lichendr,environment=preview,model=bioclip2 \
  --quiet
gcloud run services describe "$service" --project="$project" --region="$region" --format='yaml(status.url,status.conditions,spec.template.spec.containerConcurrency,spec.template.spec.containers[0].resources)'
