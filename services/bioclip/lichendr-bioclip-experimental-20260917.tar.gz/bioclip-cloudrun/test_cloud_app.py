import importlib
import sys
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

sys.path.insert(0, str(Path(__file__).parent / "worker"))


def configured(monkeypatch):
    import app
    monkeypatch.setenv("BIOCLIP_WORKER_TOKEN", "t" * 48)
    monkeypatch.setattr(app, "ENABLED", True)
    monkeypatch.setattr(app, "HEAD_PATH", "test.npz")
    monkeypatch.setattr(app, "HEAD_SHA256", "digest")
    monkeypatch.setattr(app, "_state", {"encoder": None, "head": None})
    sys.modules.pop("cloud_app", None)
    return importlib.import_module("cloud_app")


def test_rejects_missing_token_before_parsing_body(monkeypatch):
    module = configured(monkeypatch)
    response = TestClient(module.application).post("/suggest-regions", content="not-json")
    assert response.status_code == 401


def test_readiness_requires_both_models(monkeypatch):
    module = configured(monkeypatch)
    client = TestClient(module.application)
    assert client.get("/ready").status_code == 503
    module.worker._state.update(encoder=object(), head=object())
    assert client.get("/ready").json() == {"ready": True}


def test_authenticated_request_reaches_existing_validation(monkeypatch):
    module = configured(monkeypatch)
    response = TestClient(module.application).post("/suggest-regions", json={}, headers={"Authorization": "Bearer " + "t" * 48})
    assert response.status_code == 422


def test_missing_secret_prevents_startup(monkeypatch):
    configured(monkeypatch)
    monkeypatch.delenv("BIOCLIP_WORKER_TOKEN")
    sys.modules.pop("cloud_app", None)
    with pytest.raises(RuntimeError, match="strong"):
        importlib.import_module("cloud_app")
