"""Replay the frozen candidate; no training or threshold selection here."""
import json
import shutil
import sys
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from experimental import load_experimental, LABELS
from head import HeadValidationError

ROOT = Path(__file__).resolve().parents[4]
BUNDLE = Path(__file__).resolve().parents[2] / "artifacts/experimental"


def test_frozen_predictions_match_independent_evaluation():
    study = ROOT / "experiments/inat-complete-20260917/evaluation"
    if not study.exists():
        pytest.skip("Local independently frozen study not bundled in container")
    with np.load(study / "new-embeddings.npz", allow_pickle=False) as z:
        features, ids = z["features"], list(z["ids"])
    output = load_experimental(str(BUNDLE)).compare(features, ids)
    expected = json.loads((study / "report.json").read_text())["new_predictions"]
    assert [s["decision"] for s in output["suggestions"]] == [s["predictions"]["primary"] for s in expected]
    assert all(s["status"] == "pending" for s in output["suggestions"])
    assert len(output["suggestions"]) == 75


def test_corrupt_policy_is_rejected(tmp_path):
    shutil.copytree(BUNDLE, tmp_path / "bundle")
    (tmp_path / "bundle/rejection-policy.json").write_text('{"margin_min":0}')
    with pytest.raises(HeadValidationError):
        load_experimental(str(tmp_path / "bundle"))


def test_unsupported_embeddings_rejected():
    h = load_experimental(str(BUNDLE))
    with pytest.raises(HeadValidationError):
        h.compare(np.full((1, 768), np.nan), ["r"])
    assert len(LABELS) == 5
